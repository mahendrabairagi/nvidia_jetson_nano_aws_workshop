#!/usr/bin/env python3
import numpy as np
from dlr import DLRModel
import greengrasssdk
from labels import labels

mqtt_client = greengrasssdk.client('iot-data')
model_resource_path =  ('/ml_model')
dlr_model = DLRModel(model_resource_path, 'cpu')

def predict(image):
    image = np.load(image).astype(np.float32)
    input_data = {'data': image}
    print('Testing inference...')
    prediction_scores = dlr_model.run(input_data)
    max_score_id = np.argmax(prediction_scores)
    max_score = np.max(prediction_scores)
    print(max_score_id)
    return max_score, max_score_id

def send_mqtt_message(message):
    mqtt_client.publish(topic='neo-detect', payload=message)

# run loop
while True:
    file_name = "dog.npy"
    probs, classes = predict(file_name)
    msg = '{"class":"' + labels[classes] + '"' + ',"confidence":"' + str(probs) +'"}'
    print(msg)
    send_mqtt_message(msg)

# The dummy lambda handler to be invoked in Greengrass
def lambda_handler(event, context):
    pass

